# Observation protocol

Use this protocol to turn a live component into evidence for an independent implementation.

## 1. Establish the boundary

Record:

- Target URL and the exact public examples inspected.
- Whether source/usage tabs are public, authenticated, paid, or locked.
- Which evidence comes from rendered UI, accessible DOM, computed style, or public assets.
- Which decisions are inferred by the reconstruction.

Stop at access controls. A locked source panel is not an invitation to extract hidden source from bundles.

## 2. Build an interaction ledger

Create one row per transition:

| Variant | Start state | Input | Immediate semantic change | Motion | Settled state | Focus | Scroll/URL |
|---|---|---|---|---|---|---|---|
| Card | Front | Click/Enter/Space | Back becomes accessible | Rotate Y | Back | Back trigger | Unchanged |
| Modal | Closed | Activate | Trigger disabled/expanded | Translate + scale + rotate + overlay | Open | Close button | Locked |
| Modal | Open | Escape | Trigger collapsed/enabled | Reverse geometry | Closed | Trigger | Restored |

Add rows for links, backdrop, Tab loops, fullscreen, responsive breakpoints, and interrupted animation.

## 3. Capture stable UI facts

For each state, record:

- Bounding rectangle and aspect ratio.
- Font family, size, weight, line height, and letter spacing.
- Background, border, radius, shadow, opacity, blur, and saturation.
- Perspective, transform origin, backface visibility, and stacking.
- Accessible name, role, `aria-*`, `inert`, `disabled`, and tab order.
- Image URL, intrinsic dimensions, object fit, crop, and alt text.

Prefer computed values and screenshots over visual guesses.

## 4. Sample motion without the Animation domain

Low-level browser bridges may reject `Animation.enable`. This means the bridge does not expose that CDP method; it does not mean the target blocks observation.

Use a Runtime evaluation to arm a frame sampler, then activate the UI with the browser's normal click or keyboard API. Adapt selectors and fields to the component:

```js
window.__uiMotionSamples = [];
(() => {
  const node = document.querySelector(".moving-element");
  const started = performance.now();
  const sample = now => {
    const rect = node.getBoundingClientRect();
    const style = getComputedStyle(node);
    const matrix = new DOMMatrixReadOnly(style.transform === "none" ? undefined : style.transform);
    const rotateY = Math.atan2(-matrix.m13, matrix.m11) * 180 / Math.PI;

    window.__uiMotionSamples.push({
      t: now - started,
      x: rect.x,
      y: rect.y,
      width: rect.width,
      height: rect.height,
      rotateY,
      opacity: Number(style.opacity)
    });

    if (now - started < 900) requestAnimationFrame(sample);
  };
  requestAnimationFrame(sample);
})();
```

After activation and settling, retrieve `JSON.stringify(window.__uiMotionSamples)`.

For a simple property, normalize each frame:

```text
timeOffset = elapsed / totalDuration
progress   = (value - startValue) / (endValue - startValue)
```

Keep enough points to preserve the curve while removing frame-to-frame noise. Use those `[offset, progress]` pairs as linear Web Animation keyframes.

## 5. Observe interruption and reversal

Activate once, wait for roughly 20–40% of the transition, then activate the reverse action.

Record whether the reference:

- Jumps to a canonical state.
- Waits for the current animation.
- Reverses from the current visual transform.
- Uses a fixed duration or scales duration by remaining distance.
- Changes focus and ARIA state immediately or at settlement.

An implementation that only handles settled endpoints is incomplete when the reference supports interruption.

## 6. Observe modal and focus behavior

Measure both source and target rectangles. Test:

- Focus immediately after open.
- Tab and Shift+Tab order and wraparound.
- Escape, backdrop, and close-button paths.
- Focus during closing and after unmount.
- HTML/body overflow, scrollbar gap, and scroll position before/after.
- `aria-expanded`, `aria-modal`, hidden/inert content, and trigger disabled state.
- Open and close while fullscreen is active.

If a modal root is outside the fullscreen subtree, it can exist in the DOM yet remain visually absent. Include the modal layer in the fullscreen tree or fullscreen the document root and isolate the chosen demo with CSS.

## 7. Handle assets

- Reuse only public assets the browser is already allowed to load.
- Do not expose signed URLs, cookies, tokens, or local request identifiers.
- Prefer local copies for repeatable QA and offline artifacts.
- Preserve intrinsic dimensions and meaningful alt text.
- Deduplicate repeated binary data URLs by assigning a shared asset from script rather than embedding the same bytes twice.

