# Interaction reconstruction QA matrix

Use this as an acceptance gate. Mark unavailable cases explicitly instead of silently skipping them.

## Visual and asset checks

| Check | Pass condition |
|---|---|
| Default viewport | Layout, spacing, typography, crop, radius, blur, and layering match the observed state |
| Narrow viewport | Responsive layout works and `scrollWidth - innerWidth` equals zero |
| Assets | Every image is complete and has nonzero `naturalWidth` and `naturalHeight` |
| Offline artifact | No runtime image, script, stylesheet, or font dependency remains unless intentionally documented |
| Console | No implementation-created warning or error |

Suggested browser assertion:

```js
JSON.stringify({
  overflowX: document.documentElement.scrollWidth - innerWidth,
  images: [...document.images].map(image => ({
    alt: image.alt,
    complete: image.complete,
    width: image.naturalWidth,
    height: image.naturalHeight
  }))
})
```

## Two-sided card checks

| Input/state | Pass condition |
|---|---|
| Click front | Reaches back state with expected transform and duration |
| Enter front | Same semantic transition as click |
| Space front | Same semantic transition as click |
| Reverse | Returns to front with correct focus and ARIA/inert state |
| Rapid reverse | Starts from current transform, settles cleanly, and leaves no animation running |
| Multiple cards | Each card retains independent state |
| Back link | Activates the link without flipping the card |
| Reset | Restores every card without stealing unexpected focus |

At each endpoint verify:

- Visible face has `aria-hidden="false"` and is not inert.
- Hidden face has `aria-hidden="true"` and is inert.
- Focus points to a control on the visible face.
- `getAnimations().length` returns zero after settlement.

## Modal checks

| Phase | Pass condition |
|---|---|
| Open start | Trigger becomes expanded/disabled; page becomes inert/hidden; scroll locks |
| Open motion | Source rectangle continuously moves/scales/rotates into target rectangle |
| Open settled | Panel is centered, expected face is visible, and initial focus is correct |
| Tab | Focus stays inside and wraps in both directions |
| Internal flip | Visible face, focus, ARIA/inert, and transform stay synchronized |
| Link | Link remains independently usable and modal stays open |
| Escape | Reverse motion runs and trigger focus is restored |
| Backdrop | Same close contract as Escape |
| Close button | Same close contract as Escape |
| Scroll restore | Original scroll position and overflow styles are restored |
| Open during close | Behavior follows the defined state machine without duplicate panels |
| Fullscreen | Modal layer remains visible and focusable inside the fullscreen tree |

## Responsive geometry checks

Test at the default viewport and at least one phone-width viewport. Add the reference's actual breakpoints when known.

Verify:

- Card width never exceeds available content width.
- Aspect ratio remains intentional.
- Modal width uses viewport-aware bounds.
- Modal height fits the tested viewport or becomes safely scrollable.
- Text does not clip and controls retain adequate hit areas.
- Temporary viewport overrides are reset after testing.

## Reduced-motion check

When `prefers-reduced-motion: reduce` is active:

- State changes remain functional.
- Motion duration becomes negligible or transforms are disabled.
- Focus, ARIA/inert, scroll lock, and dismissal behavior remain identical.

## Delivery gate

Do not hand off until all applicable rows pass, the runnable artifact exists, and final file links point to the actual deliverables. Report any skipped case and why.

