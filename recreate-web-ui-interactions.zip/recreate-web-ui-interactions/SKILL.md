---
name: recreate-web-ui-interactions
description: Reconstruct a public web page or component as production-quality code by observing its rendered UI and behavior in a real browser, measuring geometry and animation frames, modeling keyboard, modal, focus, scroll, fullscreen, and responsive states, then verifying the result. Use when users ask to 复刻、还原、抓取 or clone UI/UX, animations, or interactions from a URL, screenshot, or live demo, especially when static HTML is insufficient, source code is locked, or low-level animation CDP commands are unavailable. Never use it to bypass authentication, paywalls, locked source, or access controls.
---

# Recreate Web UI Interactions

Rebuild observable behavior, not hidden implementation. Produce an independent implementation supported by browser evidence and interaction QA.

## Load the required guidance

- Load the available Browser control skill before any live-page inspection and follow its browser-selection rules.
- Load the HTML skill when the deliverable is a standalone HTML artifact. Follow the existing repository stack when working inside an application.
- Read [references/observation-protocol.md](references/observation-protocol.md) before observing animation, modal, keyboard, gesture, or focus behavior.
- Read [references/qa-matrix.md](references/qa-matrix.md) before implementation so the observed states become acceptance tests.

## Define the outcome

1. Identify every public variant or example on the target page.
2. Reproduce visible UI, state transitions, animation timing, input behavior, accessibility semantics, and responsive behavior.
3. Deliver runnable code and evidence of verification.
4. Separate observed facts from implementation inferences.

If the user supplies no repository or framework but expects a runnable result, default to a self-contained HTML artifact and state that assumption without pausing.

## Respect the source boundary

- Inspect public rendered DOM, computed styles, accessible state, geometry, browser-loaded public assets, and behavior caused by normal user inputs.
- Do not bypass sign-in, paywalls, locked Code tabs, authorization gates, or source-protection controls.
- Do not claim to have copied source when only behavior was observed.
- If source is locked, label the result as an independent behavior reconstruction.
- Treat bundled or minified scripts as implementation artifacts, not permission to defeat a lock or reconstruct proprietary source verbatim.

## Execute the workflow

### 1. Inventory the surface

- Capture a DOM snapshot and screenshots at the default viewport.
- Enumerate variants, faces, controls, links, overlays, modal states, and responsive layouts.
- Record copy, public asset URLs, alt text, dimensions, typography, colors, radii, borders, blur, perspective, transforms, and stacking.
- Build an interaction matrix with trigger, start state, intermediate state, settled state, focus, ARIA/inert, scroll, URL, and dismissal behavior.

Do not start implementation after inspecting only the default screenshot.

### 2. Observe behavior with real input

- Exercise click, pointer, Enter, Space, Tab, Shift+Tab, Escape, backdrop, close button, and links where applicable.
- Test rapid repeated activation and reversal while an animation is still running.
- Inspect `aria-*`, `inert`, `disabled`, active focus, scroll lock, scrollbar compensation, URL/hash changes, and animation cleanup.
- Sample bounding boxes and computed transforms on animation frames. Normalize measurements into progress curves instead of guessing easing names.
- When `Animation.enable` or another low-level CDP command is blocked, use `Runtime.evaluate`, `requestAnimationFrame`, `getBoundingClientRect()`, `getComputedStyle()`, `DOMMatrixReadOnly`, and `getAnimations()` as described in the observation protocol.

### 3. Model an explicit state machine

Represent component behavior before styling it. Typical states include:

- Two-sided card: `front`, `turning-to-back`, `back`, `turning-to-front`.
- Morphing modal: `closed`, `opening`, `open`, `closing`, plus the visible face.

Define what happens when a new action arrives during every transitional state. Preserve the current visual transform, cancel the old animation, and animate the remaining distance when reversing.

Update semantic state at activation time so focus and screen-reader state do not lag behind decorative motion.

### 4. Implement the smallest faithful version

- Use semantic buttons and links; do not nest interactive controls.
- Keep reverse-face links independent from the card flip trigger.
- Use `backface-visibility`, `transform-style: preserve-3d`, and measured perspective for 3D cards.
- Calculate modal start and target geometry from live bounding rectangles. Do not hardcode desktop coordinates.
- Mount modal content in a layer that remains visible in fullscreen mode.
- Lock scrolling without causing a layout jump, trap focus, support Escape and backdrop close, and restore focus and scroll on dismissal.
- Add `prefers-reduced-motion` behavior.
- Use local public assets when allowed. Embed assets for a standalone artifact instead of depending on hotlinks.
- Use [scripts/embed-assets.mjs](scripts/embed-assets.mjs) when replacing asset placeholders with data URLs.

Prefer the Web Animations API or the repository's existing motion system. Recreate the observed curve with measured keyframe offsets when a named easing cannot express it.

### 5. Verify in a real browser

Run the complete matrix in [references/qa-matrix.md](references/qa-matrix.md). At minimum verify:

- Default and narrow viewport layout with zero unintended horizontal overflow.
- Mouse and keyboard activation.
- Independent component state.
- Interrupted and reversed animation.
- Modal geometry, focus trap, Escape, backdrop, close button, focus restore, and scroll restore.
- Modal behavior while fullscreen is active.
- Loaded images with nonzero natural dimensions.
- No console errors or warnings introduced by the implementation.
- No live animations left after settled states.

Reload after each code change before continuing browser verification when hot reload is unavailable.

For a standalone HTML artifact, run:

```bash
node scripts/check-standalone.mjs path/to/artifact.html
```

Do not mark the task complete merely because a screenshot looks close.

## Deliver the result

- Link the runnable artifact or changed application files.
- Summarize the reproduced variants and interactions.
- Report tested viewport sizes and behavioral checks.
- State any unverified or inferred behavior explicitly.
- State that locked source was not copied when that boundary applied.
- Include one useful preview, but treat the runnable artifact as the primary deliverable.

