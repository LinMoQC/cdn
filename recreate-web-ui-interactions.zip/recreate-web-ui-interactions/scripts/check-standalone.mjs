#!/usr/bin/env node

import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

const [htmlArg] = process.argv.slice(2);

if (!htmlArg) {
  console.error("Usage: node check-standalone.mjs ARTIFACT.html");
  process.exitCode = 2;
} else {
  const htmlPath = resolve(htmlArg);
  const html = await readFile(htmlPath, "utf8");
  const failures = [];

  if (!/^\s*<!doctype html>/i.test(html)) failures.push("Missing HTML doctype");

  const placeholders = [...html.matchAll(/__ASSET_[A-Z0-9_]+__/g)].map(match => match[0]);
  if (placeholders.length) {
    failures.push(`Unresolved placeholders: ${[...new Set(placeholders)].join(", ")}`);
  }

  const networkPatterns = [
    /<(?:img|script|source|video|audio)\b[^>]*\bsrc\s*=\s*["']https?:\/\//gi,
    /<link\b[^>]*\bhref\s*=\s*["']https?:\/\//gi,
    /url\(\s*["']?https?:\/\//gi
  ];
  if (networkPatterns.some(pattern => pattern.test(html))) {
    failures.push("Runtime network asset dependency found");
  }

  if (/<img\b[^>]*\bsrc\s*=\s*["']\s*["']/i.test(html)) {
    failures.push("Image with an empty src attribute found");
  }

  const ids = [...html.matchAll(/\bid\s*=\s*["']([^"']+)["']/gi)].map(match => match[1]);
  const duplicateIds = ids.filter((id, index) => ids.indexOf(id) !== index);
  if (duplicateIds.length) {
    failures.push(`Duplicate static ids: ${[...new Set(duplicateIds)].join(", ")}`);
  }

  const summary = {
    file: htmlPath,
    bytes: Buffer.byteLength(html),
    embeddedDataUrls: (html.match(/data:[^;,"']+[;,]/g) || []).length,
    staticIds: ids.length,
    failures
  };

  console.log(JSON.stringify(summary, null, 2));
  if (failures.length) process.exitCode = 1;
}

