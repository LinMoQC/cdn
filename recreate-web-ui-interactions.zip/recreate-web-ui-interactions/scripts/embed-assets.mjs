#!/usr/bin/env node

import { readFile, writeFile } from "node:fs/promises";
import { extname, resolve } from "node:path";

const [inputArg, outputArg, ...assetArgs] = process.argv.slice(2);

if (!inputArg || !outputArg || assetArgs.length === 0) {
  console.error("Usage: node embed-assets.mjs INPUT_HTML OUTPUT_HTML PLACEHOLDER=ASSET_PATH [...]");
  process.exitCode = 2;
} else {
  const mimeByExtension = {
    ".avif": "image/avif",
    ".gif": "image/gif",
    ".jpeg": "image/jpeg",
    ".jpg": "image/jpeg",
    ".png": "image/png",
    ".svg": "image/svg+xml",
    ".webp": "image/webp",
    ".woff": "font/woff",
    ".woff2": "font/woff2"
  };

  const inputPath = resolve(inputArg);
  const outputPath = resolve(outputArg);
  let html = await readFile(inputPath, "utf8");

  for (const specification of assetArgs) {
    const separator = specification.indexOf("=");
    if (separator < 1 || separator === specification.length - 1) {
      throw new Error(`Invalid asset specification: ${specification}`);
    }

    const placeholder = specification.slice(0, separator);
    const assetPath = resolve(specification.slice(separator + 1));
    if (!html.includes(placeholder)) {
      throw new Error(`Placeholder not found: ${placeholder}`);
    }

    const mime = mimeByExtension[extname(assetPath).toLowerCase()];
    if (!mime) throw new Error(`Unsupported asset type: ${assetPath}`);

    const bytes = await readFile(assetPath);
    const dataUrl = `data:${mime};base64,${bytes.toString("base64")}`;
    html = html.replaceAll(placeholder, dataUrl);
  }

  const remaining = [...html.matchAll(/__ASSET_[A-Z0-9_]+__/g)].map(match => match[0]);
  if (remaining.length) {
    throw new Error(`Unresolved placeholders: ${[...new Set(remaining)].join(", ")}`);
  }

  await writeFile(outputPath, html);
  console.log(`Embedded ${assetArgs.length} asset(s) into ${outputPath}`);
}

